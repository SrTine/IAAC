%practica 5- red neuronal - brazo robot

clear all

load datos.mat
%datos1 = (datos_prueba.datos.mat)
%preparacion de datos

input = [datos.efector(1:end-1,:),repmat(datos.efector(end,:),size(datos.efector,1)-1,1)]';
output_base = datos.angulo(:,1)';
output_hombro = datos.angulo(:,2)';
output_codo = datos.angulo(:,3)';
output_muneca = datos.angulo(:,4)';
