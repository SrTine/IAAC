function guardar
suck=get(gcf,'UserData');
datos=suck{3};
uisave('datos','datos')